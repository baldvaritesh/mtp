outlierAnomaly = function(inputMatrix, Threshold, errorTolerance)
{
        # Initialization
        
        cosineSimilarityMatrix = inputMatrix

        graphNodes = nrow(cosineSimilarityMatrix)
        discreteMatrix = matrix(rep(0, graphNodes * graphNodes), graphNodes, graphNodes)
        similarityMatrix = matrix(c(rep(0, graphNodes * graphNodes)), graphNodes, graphNodes)

        # end Initialization

        #Check for empty input matrix

        if(toString(inputMatrix[1, 1]) == "NA") 
        {
                print("Input Matrix is Empty")
                return()
        }
        #end

        # Implementing Algorithm Outrank-b from "Outlier Detection Using Random Walks" paper
        # Making the values discrete using the Threshold as a cutoff

         cosineSimilarityMatrix[cosineSimilarityMatrix >= Threshold] = 1
         cosineSimilarityMatrix[cosineSimilarityMatrix < Threshold] = 0
 
         discreteMatrix = cosineSimilarityMatrix
  
	
        # Similarity Matrix
		# This is the new similarity calculated based on the concept of shared common neighbors

        columnFirst = columnSecond = 0
        
        for(columnFirst in 1: graphNodes)
        {
                for(columnSecond in 1: graphNodes)
                {
                        #Computing the Similarity Matrix using shared neighbours
                                
                        firstNode = c(discreteMatrix[, columnFirst])
                        secondNode = c(discreteMatrix[, columnSecond])
                        similarityMatrix[columnFirst, columnSecond] = similarityMatrix[columnSecond, columnFirst] = firstNode %*% secondNode ;

				# Dot product works because if firstNode = {0, 1, 1} and secondNode = {1, 0, 1}
				# where each column is firstNode, secondNode and thirdNode then the no of shared eighbours between firstNode & secondNode would be 1
                # which is the dot product. 
                # This works because you dont have to count the fact that firstNode and  secondNode are neighbours to each other.
                
                }

                similarityMatrix[columnFirst, columnFirst] = 0
                 
        }

        #Call the rankAnomaly function that will perform the random walk and calculate and rank the connectivity values                
            outRankA(similarityMatrix, errorTolerance)
}
