#Implementing algorithm Outlier-a from "Outlier Detection Using Random Walks"

outRankA = function(similarityMatrix, epsilon)
{
        #Declaration of Variables 

        # No of columns in the matrix, Its a square matrix so it does not matter whether you consider the no of rows or colums
        ncolsSM = ncol(similarityMatrix); 
        Ranks = c(rep(0, ncolsSM));
        connectivityValues = c(rep(0, ncolsSM));
        previousConnectivityValues = c(rep(0, ncolsSM));
        dampingFactor = 0.1; 
        delta = 0;
        #end Declaration

        #Initialization 
        errorTolerance = epsilon;
        similarityMatrix = as.matrix(similarityMatrix);
		
        # initialize trank vector 
        for(vertex in 1: ncolsSM)
                Ranks[vertex] = 1;

        # initialize the connectivity vector 
        for(vertex in 1: ncolsSM)
                connectivityValues[vertex] = 1/ncolsSM; 

        # forms the transistion matrix using the Similarity Matrix Calculated in function "anomalyOutlierB" function
        transitionPM = transitionMatrix(ncolsSM, similarityMatrix); 

        #Transpose of transitionPM 
        transitionPM = t(transitionPM); 

        #End Initialization

        while(delta<errorTolerance)
        {
                previousConnectivityValues = connectivityValues;
        
                #Calculating the new connectivity value
                connectivityValues = iterate(previousConnectivityValues, transitionPM,dampingFactor);
                delta = 0;
                delta = dist(rbind(connectivityValues, previousConnectivityValues), method = "euclidean"); 
        }

        #Calculating the Ranks of Each Vertex Using the Connectivity Values
        Ranks = rankData(connectivityValues)
		
        Vertex = 1: ncolsSM

        #Output
        return(cbind(Vertex, connectivityValues, Ranks))
}

# The trasition probability matrix is calculated by diving each row with total sum
# of that row

transitionMatrix = function(ncolsSM, similarityMatrix)
{
        S = matrix(c(rep(0, ncolsSM*ncolsSM)), ncolsSM, ncolsSM);

        for(row in 1: ncolsSM)
         {
                total = 0.0

                for(column in 1: ncolsSM)
                        total = total + similarityMatrix[row, column];

                # Check for divide by zero error
                if(total == 0) 
                        total = 1;
                
                for(column in 1: ncolsSM)
                        S[row, column] = similarityMatrix[row, column]/total;
                
        }
        return(S);
}
 
#Calculates the new connectivity value using previous Connectivity and Transistion Probability matrix.
#This mimics Random Walk. A vertes i goes to a random node with probability d/n and to its neighbours with proability (1 - d)
# similar to Pagerank & Perron - frobenius technique

iterate = function(previousConnectivityValues, transitionPM, dampingFactor)
{
        ncolsSM = length(previousConnectivityValues)
        connectivityValues = c(rep(0, ncolsSM))

        for(row in 1: ncolsSM)
        { 	
                vertex = row 
                connectivityValues[vertex] = (dampingFactor/ncolsSM)
                
                for(column in 1: ncolsSM)
                        connectivityValues[vertex] = connectivityValues[vertex] + (1 - dampingFactor) *(transitionPM [row, column] %*% previousConnectivityValues[vertex])
        }

        return(connectivityValues)
}

#Ranking the vertices according to their connectivity values

rankData = function(connectivityValues)
{
 
        connectivityLength = length(connectivityValues)
		
		# Sorting the Connectivity values
        sortedConnectivity = c(sort(connectivityValues)) 
        
        tempRank = c(1: connectivityLength)

        for(vertex in 1:connectivityLength)
                tempRank[vertex] = vertex;
                
        connectivityRank = c(1: connectivityLength)
        
        for(connectivityValuesIndex in 1: connectivityLength)
        {
                for(sortedConnectivityIndex in 1: connectivityLength)
                {
                        if(connectivityValues[connectivityValuesIndex] == sortedConnectivity[sortedConnectivityIndex])
                        {
                                connectivityRank[connectivityValuesIndex] = tempRank[sortedConnectivityIndex]
                                break;
                        }
                }
        }

        return(connectivityRank)
}
