cosineSimilarity = function(InputMatrix)
{
	#Initilaization
	n = ncol(InputMatrix)
	similarityMatrix = matrix(rep(0,n*n),n,n)
	
	#Calculating Cosine Similarity
	for( i  in 1:n)
	{
		for(j in 1:n)
		{
			X = InputMatrix[,i]%*%InputMatrix[,j]
			Y = sqrt(InputMatrix[,i]%*%InputMatrix[,i])
			Z = sqrt(InputMatrix[,j]%*%InputMatrix[,j])
			
			#Check for divide by zero error
				if(Y==0)
				{
					Y=1
				}
				if(Z==0)
				{
					Z=1
				}
				
			similarityMatrix[i, j] = X/(Y*Z)
		}
	}

	for(i in 1:n)
		similarityMatrix[i,i]=0

	return(similarityMatrix)
}
