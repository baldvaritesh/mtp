multivariateAnomaly = function(X, Y, r, sig, nv, d = 0.1)
{
	Kalign = kernelAlign(X, Y, r, sig, nv);
	anomaly(Kalign$KX, Kalign$KY, d);
}

anomaly = function(KX, KY, d = 0.1)
{
	KX = round(KX, digits = 4);
	n = ncol(KX);
	
	if (sum(KX<0) > 0)
	{
		minKX = min(KX);
		KX = KX - minKX;
	}

	S = KX;
	sums = colSums(S);

	# This prevents Inf values in matrix. Checks division by zero. 
	ind = which(sums == 0);
	sums[ind] = 1;

	Mx = repmat(sums, 1, n);

	S = S/t(Mx);

	maxinter = 1500;

	c = rowSums(KX);
	
	c = c/sum(c);

	cold = 0;
	ep = 10^(-15);

	for (i in 1:maxinter)
	{
		c = d/n + (1-d) * (S %*% c);

		if (sqrt(sum((c-cold)^2)) < ep)
		{
			msg = sprintf('coverged after %d iterations',i);
	      	print(msg);
			return (cbind("Time Stamp" = 1: length(c[,1]), "Connectivity" = c, "Rank" = rankData(c)));
		}
		cold = c;
	}

	msg = sprintf('max %d iterations with error %f', maxinter, sqrt(sum((c-cold)^2)));
	print(msg);
}

repmat = function(B, m, n)
{
	Mx = as.matrix(B);
	mx = nrow(Mx);
	nx = ncol(Mx);
	return(matrix(t(matrix(Mx, mx, nx*n)), mx*m ,nx*n, byrow = TRUE));
}

kernelAlign = function(X, Y, r = 0, sig = 0.1, nv = 1)
{
	n = ncol(X);

	if(n <= r)
	{
		print("Value of r should be less than the number of columns of the predictor and target variables")
		return (FALSE);
	}

	XX = matrix(X[, 1:(n - r)], ncol = (n - r));
	YY = matrix(Y[, (r + 1): ncol(Y)], ncol = ncol(Y) - r);

	if(r > 0)
		for(i in 1: r)
		{
			XX = rbind(XX, matrix(X[, (i + 1): (n - r + i)], ncol = (n-r)));
		}

	XM = matrix(XX, ncol = (n-r));

	# exp(-Inf) = 0 in R
	KerX = RBFMeasure(XM, sig);
	KY = t(YY) %*% YY;

	DX = matrix(eigen(KerX)$values[1: nv], ncol = nv) ;
	
	Identity = diag(nv)
	for (diag in 1: nv)
		Identity[diag, diag] = DX[diag];

	DX = Identity

	VX = matrix((eigen(KerX)$vectors)[, 1: nv], ncol = nv);

	w = matrix(rep(0, nv), nrow=1);

	for (i in (1: nv))
	{
		w[1, i] = sum((VX[, i] %*% t(VX[, i]) * KY))
	}

	if(sum(w) != 0)
		w = w / sqrt(sum(w^2))

	KX = matrix(0, ncol(XX), ncol(XX))

	for (i in (1:nv))
		KX = KX + w[1, i] * (VX[, i] %*% t(VX[, i]));

	#objo = sum(KerX * KY) / sqrt(sum(KerX * KerX)) / sqrt(sum(KY * KY));
	#objn = sum(KX * KY) / sqrt(sum(KX * KX)) / sqrt(sum(KY * KY));

	#msg = sprintf("kernel alignment from %f to %f", objo, objn);
	#print(msg)
	#anomaly(KX, KY, d)
	return (list("KX" = KX, "KY" = KY))
}

RBFMeasure = function(X, sig)
{
	n = ncol(X);
	D = matrix(0, n, n);

	for(i in (1:n))
		for(j in (1:n))
		{
			d = 0
			for(k in (1:nrow(X)))
				D[i, j] = D[i, j] + (X[k, i] - X[k, j]) * (X[k, i] - X[k, j]);
		}
	KerX = exp((-0.5 * D) / (sig * sig));
	return (KerX);
}

rankData = function(connectivityValues)
{

	connectivityLength = length(connectivityValues)
	
	# Sorting the Connectivity values
	sortedConnectivity = c(sort(connectivityValues))
	
	tempRank = c(1: connectivityLength)
	
	for(vertex in 1:connectivityLength)
        tempRank[vertex] = vertex;
	
	connectivityRank = c(1: connectivityLength)
	
	for(connectivityValuesIndex in 1: connectivityLength)
	{
		for(sortedConnectivityIndex in 1: connectivityLength)
		{
	    	if(connectivityValues[connectivityValuesIndex] == sortedConnectivity[sortedConnectivityIndex])
			{
	        	connectivityRank[connectivityValuesIndex] = tempRank[sortedConnectivityIndex]
	            break;
			}
		}
	}

	return(connectivityRank)
}

matrixAlign = function(KX, KY)
{
	Values = eigen(KX)$values
	Vectors = eigen(KX)$vectors
	n = ncol(KX)
	Interim = Vectors %*% t(Vectors)

	FB = frobenius.prod(Interim,KY)

	alpha = Values + (FB/2)
	n = length(alpha)

	diagmatrix_alpha = diag(alpha, nrow=n, ncol=n) 
	K = Vectors %*% diagmatrix_alpha %*% t(Vectors)

	return(K)
}
